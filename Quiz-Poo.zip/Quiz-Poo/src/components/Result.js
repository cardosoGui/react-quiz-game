import React from "react";
import ReactCSSTransitionGroup from "react-addons-css-transition-group";
import ps1 from "../svg/ps1.svg";

function Result(props) {
  return (
    <ReactCSSTransitionGroup
      className="container result"
      component="div"
      transitionName="fade"
      transitionEnterTimeout={1000}
      transitionLeaveTimeout={500}
      transitionAppear
      transitionAppearTimeout={500}
    >
      <div>
        <div>
          <img src={ps1} className="App-logo" alt="logo" />
        </div>
        Você Prefere <strong>{props.quizResult}</strong>!
      </div>
    </ReactCSSTransitionGroup>
  );
}

Result.propTypes = {
  quizResult: React.PropTypes.string.isRequired
};

export default Result;
