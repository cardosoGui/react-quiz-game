import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import "./index.css";
import { BrowserRouter as Router } from "react-router-dom";
import { Route, Link } from "react-router-dom";
import Home from "../src/pages/Home";
import Header from "../src/layout/Header";
import Footer from "../src/layout/Footer";

const BaseLayout = () => (
  <div className="base">
    <Header />
    <div className="pages">
      <Route path="/" exact component={Home} />
      <Route path="/app" component={App} />
    </div>
    <Footer />
  </div>
);

ReactDOM.render(
  <Router>
    <BaseLayout />
  </Router>,
  document.getElementById("root")
);
